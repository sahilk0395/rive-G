NOTE: This demo font is for PERSONAL USE ONLY! But any donation are very appreciated. 

Paypal account for donation : https://www.paypal.me/dimasardhi

Link to purchase full version and commercial license:
https://www.creativefabrica.com/product/brigham-script/

If you need an extended license or corporate license, please contact us at
styleglyph@gmail.com


And follow my instagram for update : @glyphstyle

Thank you.